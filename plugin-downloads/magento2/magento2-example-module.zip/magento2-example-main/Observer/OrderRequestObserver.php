<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is provided with Magento in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * Copyright © 2022 MultiSafepay, Inc. All rights reserved.
 * See DISCLAIMER.md for disclaimer details.
 */

declare(strict_types=1);

namespace MultiSafepay\CustomValueExample\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\Data\OrderInterface;
use MultiSafepay\Api\Transactions\OrderRequest;

class OrderRequestObserver implements ObserverInterface
{
    public const ORDER_REQUEST_KEY = 'orderRequest';
    public const ORDER_KEY = 'order';
    
    /**
     * This method is an example on how to add a value retrieved from the order to the MultiSafepay transaction
     *
     * @param Observer $observer
     */
    public function execute(Observer $observer): void
    {
        /** @var OrderRequest $orderRequest */
        $orderRequest = $observer->getData(self::ORDER_REQUEST_KEY);

        /** @var OrderInterface $order */
        $order = $observer->getData(self::ORDER_KEY);

        if ($order->getExtensionAttributes() === null) {
            return;
        }
        
        // Add a custom value retrieved from the order to the MultiSafepay order request
        $orderRequest->addData([
            'var1' => $order->getExtensionAttributes()->getPickupLocationCode() ?? 'unknown'
        ]);
    }
}
