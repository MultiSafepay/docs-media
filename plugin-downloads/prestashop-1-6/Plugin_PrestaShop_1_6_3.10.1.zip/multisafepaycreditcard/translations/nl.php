<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{multisafepaycreditcard}default-bootstrap>multisafepaycreditcard_97a376261df33669b91294efb6ad92cd'] = 'MultiSafepay Creditcard';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>multisafepaycreditcard_e7a76a5d88bf2462fe399d808c154ad2'] = 'Accepteer Creditcards via MultiSafepay';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>multisafepaycreditcard_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>multisafepaycreditcard_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>multisafepaycreditcard_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>multisafepaycreditcard_52f4393e1b52ba63e27310ca92ba098c'] = 'Algemene instellingen';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>multisafepaycreditcard_3fb4d39c72a50b7de7a32d96121a8fb6'] = 'Minimaal orderbedrag voor Creditcards ';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>multisafepaycreditcard_c1090d18a8a4ba5cf5328d7a6f940cb8'] = 'Maximaal orderbedrag voor Creditcards ';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>validation_creditcard_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>validation_creditcard_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>validation_creditcard_38eb0c13548927ec00e0c21389f9fd3b'] = 'CreditCard';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>validation_creditcard_8a8127155cf5db2c4d2b324050f2f5c5'] = 'U heeft gekozen om af te rekenen middels CreditCard';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>validation_creditcard_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>validation_creditcard_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>validation_creditcard_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>validation_creditcard_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>payment_3aed7d09e08c1f284220adf1dee94fcc'] = 'Creditcards';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '( +';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';
$_MODULE['<{multisafepaycreditcard}default-bootstrap>payment_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
