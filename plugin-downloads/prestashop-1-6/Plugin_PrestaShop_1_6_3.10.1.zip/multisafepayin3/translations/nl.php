<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{multisafepayin3}default-bootstrap>multisafepayin3_d670196c5f2dd031b084d0a2cc0e6c02'] = 'Accepteer in3 betalingen via MultiSafepay';
$_MODULE['<{multisafepayin3}default-bootstrap>multisafepayin3_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepayin3}default-bootstrap>multisafepayin3_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepayin3}default-bootstrap>multisafepayin3_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepayin3}default-bootstrap>multisafepayin3_52f4393e1b52ba63e27310ca92ba098c'] = 'Algemene instellingen';
$_MODULE['<{multisafepayin3}default-bootstrap>multisafepayin3_8903422ed565f9b1e1f573d0c61e5b9b'] = 'Minimaal orderbedrag voor in3';
$_MODULE['<{multisafepayin3}default-bootstrap>multisafepayin3_032da8815ca117cf51cff8d33b11503c'] = 'Maximaal orderbedrag voor in3';
