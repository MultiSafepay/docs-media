<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepayapplepay}default-bootstrap>multisafepayapplepay_b406ad549c48678d89a06ec2f1e633ae'] = 'MultiSafepay Apple Pay';
$_MODULE['<{multisafepayapplepay}default-bootstrap>multisafepayapplepay_d670196c5f2dd031b084d0a2cc0e6c02'] = 'Accepteer Apple Pay betalingen via MultiSafepay';
$_MODULE['<{multisafepayapplepay}default-bootstrap>multisafepayapplepay_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepayapplepay}default-bootstrap>multisafepayapplepay_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepayapplepay}default-bootstrap>multisafepayapplepay_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepayapplepay}default-bootstrap>multisafepayapplepay_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepayapplepay}default-bootstrap>multisafepayapplepay_69289799f6c8df1ab56e5be6ee56e890'] = 'Minimaal orderbedrag voor Apple Pay';
$_MODULE['<{multisafepayapplepay}default-bootstrap>multisafepayapplepay_5f9bca9efc1fbcdd7714672dbd0fb842'] = 'Maximaal orderbedrag voor Apple Pay';
