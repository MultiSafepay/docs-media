var MultiSafepayPaymentComponent = function (config) {

    var paymentComponent = null;

    this.construct = function (config) {
        initializePaymentComponent();
        onSubmitCheckoutForm();
    };

    var getPaymentComponent = function () {
        if ( ! this.paymentComponent ) {
            this.paymentComponent = getNewPaymentComponent();
        }

        return this.paymentComponent;
    };

    var getNewPaymentComponent = function () {
        return new MultiSafepay(
            {
                env: config.env,
                apiToken: config.apiToken,
                order: config.orderData
            }
        );
    };

    var insertPayload = function (payload) {
        $("#multisafepay-payment-component-" + config.gateway.toLowerCase() + " input[name='payload']").val(payload);
    };

    var removePayload = function () {
        $("#multisafepay-payment-component-" + config.gateway.toLowerCase() + " input[name='payload']").val();
    };

    var initializePaymentComponent = function () {
        getPaymentComponent().init('payment', {
            container: '#multisafepay-payment-component-' + config.gateway.toLowerCase() + ' #multisafepay-payment-component',
            gateway: config.gateway,
            onLoad: state => {
                logger('onLoad');
            },
            onError: state => {
                logger('onError');
            }
        });
    };


    var onSubmitCheckoutForm = function () {
        $("#multisafepay-form-" + config.gateway.toLowerCase() + " input[type='submit']").click(function (event) {
            removePayload();
            if (getPaymentComponent().hasErrors()) {
                logger(getPaymentComponent().getErrors());
                $('#payment-confirmation button').removeClass('disabled');
                event.preventDefault();
                event.stopPropagation();
                return;
            }
            var payload = getPaymentComponent().getPaymentData().payload;
            insertPayload(payload);
            $("#multisafepay-form-" + config.gateway.toLowerCase() + " input[type='submit']").unbind('click').click();
        });
    };

    var logger = function (argument) {
        if (config.debug) {
            console.log(argument);
        }
    };

    this.construct(config);

};