<?php
/**
 * 2017 Adviva
 */

class TokenizationUtils 
{

	/* translate gateway name into int numbers */
	public static function getGatewayType($gateway = false, $cc_issuer = false) {
		$gateway = $gateway ? $gateway : Tools::getValue('gateway');
        $gateway = $gateway == 'CREDITCARD' ? $cc_issuer : $gateway;
        $gateway = $gateway == 'CONNECT'    ? ''         : $gateway;		
		switch ($gateway) {
			case 'VISA':
				return 1;
				break;
			case 'MASTERCARD':
				return 2;
				break;
			case 'AMEX':
				return 3;
				break;	
			case 'MAESTRO':
				return 4;
				break;										
			default:
				return 0;
				break;
		}	
	}

	/* translate gateway int numbers into name*/
	public static function getGatewayFromType($type) {
		switch ($type) {
			case 1:
				return 'VISA';
				break;
			case 2:
				return 'MASTERCARD';
				break;
			case 3:
				return 'AMEX';
				break;	
			case 4:
				return 'MAESTRO';
				break;										
			default:
				return 'ERROR GATEWAY NOT DEFINED';
				break;
		}	
	}	


}
