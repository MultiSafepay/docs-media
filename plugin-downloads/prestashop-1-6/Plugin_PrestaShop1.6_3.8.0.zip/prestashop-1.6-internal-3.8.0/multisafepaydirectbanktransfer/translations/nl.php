<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_26c992e2dda596f634b34d51635254a5'] = 'Request to Pay';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_d670196c5f2dd031b084d0a2cc0e6c02'] = 'Accepteer Request to Pay betalingen via MultiSafepay';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_d82664770d94c1cb1180a89264686f00'] = 'Minimaal orderbedrag voor Request to Pay';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_41c2eedb31520d6148a98234a01d5ba4'] = 'Maximaal orderbedrag voor Request to Pay';
