<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_ffedf4518d305bd4957baa03a18663d7'] = 'MultiSafepay PaySafecard';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_a427e28a843bf15b17079c22c833680d'] = 'Accepteer PaySafecard betalingen via MultiSafepay';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_9fd21b85e9c4e4b16f2aff09714bf11b'] = 'Minimaal orderbedrag voor PaySafecard';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_26bf0b1aa36b4731861cf1b9c6fe94cf'] = 'Maximaal orderbedrag voor FePaySafecardrbuy';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_paysafecard_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_ferpaysafecardbuy_0c25b529b4d690c39b0831840d0ed01c'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_ferpaysafecardbuy_6f08d5e980f55d211142dc032215b2b4'] = 'PaySafecard';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_ferpaysafecardbuy_1adc956925120704023633fc1cf06b0e'] = 'U heeft gekozen af te rekenen middels PaySafecard';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_fepaysafecardrbuy_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_fepaysafecardrbuy_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_ferpaysafecardbuy_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>payment_f1d6d3868fbf2e35f6d671a1e8774a15'] = 'PaySafecard';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';