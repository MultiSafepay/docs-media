<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaymaestro}default-bootstrap>multisafepaymaestro_bbf47203fc2859f56679ec9dc319516b'] = 'MultiSafepay Maestro';
$_MODULE['<{multisafepaymaestro}default-bootstrap>multisafepaymaestro_75a1969f316fa63ee46289ec5f4351f3'] = 'Accepteer Maestro betalingen via MultiSafepay';
$_MODULE['<{multisafepaymaestro}default-bootstrap>multisafepaymaestro_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaymaestro}default-bootstrap>multisafepaymaestro_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaymaestro}default-bootstrap>multisafepaymaestro_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaymaestro}default-bootstrap>multisafepaymaestro_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaymaestro}default-bootstrap>multisafepaymaestro_db7da0d0e7f41a97c518544fcc4b5b8c'] = 'Minimaal orderbedrag voor Maestro';
$_MODULE['<{multisafepaymaestro}default-bootstrap>multisafepaymaestro_4f3ef6c5432f076e73eb05aa90e2fda8'] = 'Maximaal orderbedrag voor Maestro';
$_MODULE['<{multisafepaymaestro}default-bootstrap>validation_maestro_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaymaestro}default-bootstrap>validation_maestro_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaymaestro}default-bootstrap>validation_maestro_2aaa3e8ae5da0cb963cd62087faf5566'] = 'Maestro';
$_MODULE['<{multisafepaymaestro}default-bootstrap>validation_maestro_a973e3a4c34c393d82c6c235ee78c62c'] = 'U heeft gekozen af te rekenen middels Maestro';
$_MODULE['<{multisafepaymaestro}default-bootstrap>validation_maestro_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaymaestro}default-bootstrap>validation_maestro_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaymaestro}default-bootstrap>validation_maestro_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaymaestro}default-bootstrap>validation_maestro_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaymaestro}default-bootstrap>payment_2aaa3e8ae5da0cb963cd62087faf5566'] = 'Maestro';
$_MODULE['<{multisafepaymaestro}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaymaestro}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';