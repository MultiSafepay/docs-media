<p align="center">
  <img src="https://www.multisafepay.com/img/multisafepaylogo.svg" width="400px" position="center">
</p>

# MultiSafepay plugin for PrestaShop 1.6

Easily integrate MultiSafepay payment solutions into your PrestaShop 1.6 webshop with the free MultiSafepay PrestaShop 1.6 plugin.

## About MultiSafepay ##
MultiSafepay is a collecting payment service provider which means we take care of the agreements, technical details and payment collection required for each payment method. You can start selling online today and manage all your transactions from one place.
## Supported Payment Methods ##
The supported Payment Methods & Gift cards for this plugin can be found over here: [Payment Methods & Gift cards](https://docs.multisafepay.com/plugins/prestashop-1-6/faq/#available-payment-methods-in-prestashop-1.6)

## Requirements
- To use the plugin you need a MultiSafepay account. You can create a test account on https://testmerchant.multisafepay.com/signup
- PrestaShop version 1.6

## Installation
Unpack the contents of the .zip archive and upload the “modules” folder via SFTP to the PrestaShop root directoy, merging the two folders.

For additional information or instructions please see our [installation & configuration manual](https://docs.multisafepay.com/plugins/prestashop-1-6/manual/)

## Configuration


1. Navigate to the backend of your webshop and navigate to Modules and Services-> Payments and Gateways

_It is essential that the MultiSafepay Core Module (MultiSafepay) is installed and configured. Reason being that all payment methods are more or less dependent on settings and/or the API key in the core module_

2. In the next screen proceed with the installation

3. Set your API key. Information about getting your API key can be found on API key page. Save the page

4. Click on the Payments tab and enable the payment methods you would like to offer.

## A gift for your contribution
We look forward to receiving your input. Have you seen an opportunity to change things for better? We would like to invite you to create a pull request on GitHub.
Are you missing something and would like us to fix it? Suggest an improvement by sending us an [email](mailto:integration@multisafepay.com) or by creating an issue.

What will you get in return? A brand new designed MultiSafepay t-shirt which will make you part of the team!

## Support
You can create issues on our repository. If you need any additional help or support, please contact <a href="mailto:integration@multisafepay.com">integration@multisafepay.com</a>
