<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_528142ccdba8b2c9ff9be865e14dcc0f'] = 'MultiSafepay Gezondheidsbon';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_eb50421227e6d181fb3f3a56e8bd665a'] = 'Accepteer Gezondheidsbon betalingen via MultiSafepay';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_c888438d14855d7d96a2724ee9c306bd'] = 'Instellingen bijgewerkt';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_8af703b2bf59cc9742883ae7f4cb0e5b'] = 'Instellingen account';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_d876ff8da67c3731ae25d8335a4168b4'] = 'API-Sleutel';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_6e147eeb6094904219d0987806735f5c'] = 'De API-Sleutel van de betreffende website in het MultiSafepay account. Indien leeg, dan wordt de API-Sleutel van de Standaard MultiSafepay configuratie gebruikt.';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_b02b464fbe0b40f0c481f17894f66747'] = 'Test account';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_138780f997031206bb8ee5390e36e08a'] = 'Gebruik LIVE-account als de API-Sleutel van een Live-account is. Gebruik TEST-account als de API-Sleutel van een Test-account is.';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>multisafepaygezondheidsbon_638ce87fab4d636ed19f2517b40a48fd'] = 'Live account';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>validation_gezondheidsbon_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>validation_gezondheidsbon_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>validation_gezondheidsbon_7948232fbe6cbfc478f77c7401a5c33a'] = 'Gezondheidsbon';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>validation_gezondheidsbon_a9de86db949bd261d92e49dbc86d6d64'] = 'U heeft gekozen om af te rekenen middels Gezondheidsbon';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>validation_gezondheidsbon_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>validation_gezondheidsbon_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>validation_gezondheidsbon_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>validation_gezondheidsbon_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaygezondheidsbon}default-bootstrap>payment_7948232fbe6cbfc478f77c7401a5c33a'] = 'Gezondheidsbon';