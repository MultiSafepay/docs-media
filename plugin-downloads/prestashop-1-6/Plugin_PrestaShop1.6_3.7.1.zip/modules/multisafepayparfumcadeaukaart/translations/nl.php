<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_da6a5685cf493cea01cb2a93840244cb'] = 'MultiSafepay Parfum Cadeaukaart';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_5b261944a4d1baae5ba87512ac934451'] = 'Accepteer Parfum Cadeaukaart betalingen via MultiSafepay';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_c888438d14855d7d96a2724ee9c306bd'] = 'Instellingen bijgewerkt';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_8af703b2bf59cc9742883ae7f4cb0e5b'] = 'Instellingen account';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_d876ff8da67c3731ae25d8335a4168b4'] = 'API-Sleutel';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_6e147eeb6094904219d0987806735f5c'] = 'De API-Sleutel van de betreffende website in het MultiSafepay account. Indien leeg, dan wordt de API-Sleutel van de Standaard MultiSafepay configuratie gebruikt.';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_b02b464fbe0b40f0c481f17894f66747'] = 'Test account';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_138780f997031206bb8ee5390e36e08a'] = 'Gebruik LIVE-account als de API-Sleutel van een Live-account is. Gebruik TEST-account als de API-Sleutel van een Test-account is.';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>multisafepayparfumcadeaukaart_638ce87fab4d636ed19f2517b40a48fd'] = 'Live account';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>validation_parfumcadeaukaart_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>validation_parfumcadeaukaart_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>validation_parfumcadeaukaart_c33327b96ba142102df5175685d73c2b'] = 'Parfum Cadeaukaart';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>validation_parfumcadeaukaart_bc4d8563942b0eeb2ebaf26b89ff4892'] = 'U heeft gekozen om af te rekenen middels Parfum Cadeaukaart';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>validation_parfumcadeaukaart_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>validation_parfumcadeaukaart_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>validation_parfumcadeaukaart_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>validation_parfumcadeaukaart_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepayparfumcadeaukaart}default-bootstrap>payment_c33327b96ba142102df5175685d73c2b'] = 'Parfum Cadeaukaart';