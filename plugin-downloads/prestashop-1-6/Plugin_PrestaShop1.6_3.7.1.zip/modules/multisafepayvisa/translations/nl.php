<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepayvisa}default-bootstrap>multisafepayvisa_1b19ecd91cdf0cd0d560af1e2e22eece'] = 'MultiSafepay Visa';
$_MODULE['<{multisafepayvisa}default-bootstrap>multisafepayvisa_14caad1dada193727258a31c9cb4575a'] = 'Accepteer VISA betalingen via MultiSafepay';
$_MODULE['<{multisafepayvisa}default-bootstrap>multisafepayvisa_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepayvisa}default-bootstrap>multisafepayvisa_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepayvisa}default-bootstrap>multisafepayvisa_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepayvisa}default-bootstrap>multisafepayvisa_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Terug naar overzicht';
$_MODULE['<{multisafepayvisa}default-bootstrap>multisafepayvisa_624c5f4d8aacf7344084665c625e35c5'] = 'Minimaal orderbedrag voor VISA';
$_MODULE['<{multisafepayvisa}default-bootstrap>multisafepayvisa_78e3657dd523e389ed5247c8b6e30f20'] = 'Maximaal orderbedrag voor VISA';
$_MODULE['<{multisafepayvisa}default-bootstrap>validation_visa_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepayvisa}default-bootstrap>validation_visa_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepayvisa}default-bootstrap>validation_visa_93d207a5540aa38f404ae593385a7b64'] = 'VISA';
$_MODULE['<{multisafepayvisa}default-bootstrap>validation_visa_47a475d8ebfc31f711aa645d2ef566a5'] = 'VISA CreditCard';
$_MODULE['<{multisafepayvisa}default-bootstrap>validation_visa_60edb6bca4afe3b780dc7c577a8c3732'] = 'U heeft gekozen om te betalen middels VISA';
$_MODULE['<{multisafepayvisa}default-bootstrap>validation_visa_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepayvisa}default-bootstrap>validation_visa_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepayvisa}default-bootstrap>validation_visa_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepayvisa}default-bootstrap>validation_visa_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepayvisa}default-bootstrap>payment_89fc0d6fe12b0e0c1af5c7a0373435a6'] = 'Visa';
$_MODULE['<{multisafepayvisa}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepayvisa}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';