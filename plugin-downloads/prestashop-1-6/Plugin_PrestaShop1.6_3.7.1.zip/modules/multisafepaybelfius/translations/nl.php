<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaybelfius}default-bootstrap>multisafepaybelfius_85b4a3b786b9645fd2457cd3f878a355'] = 'MultiSafepay Belfius';
$_MODULE['<{multisafepaybelfius}default-bootstrap>multisafepaybelfius_358838372203b7bf232f8135956ffcbb'] = 'Accepteer Belfius betalingen via MultiSafepay';
$_MODULE['<{multisafepaybelfius}default-bootstrap>multisafepaybelfius_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaybelfius}default-bootstrap>multisafepaybelfius_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaybelfius}default-bootstrap>multisafepaybelfius_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaybelfius}default-bootstrap>multisafepaybelfius_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaybelfius}default-bootstrap>multisafepaybelfius_f9b3ff95f85aa84d288614232616f138'] = 'Minimaal orderbedrag voor Belfius';
$_MODULE['<{multisafepaybelfius}default-bootstrap>multisafepaybelfius_f0d8c9bcb5fdc7e76f313d8cfa43f41c'] = 'Maximaal orderbedrag voor Belfius';
$_MODULE['<{multisafepaybelfius}default-bootstrap>validation_belfius_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaybelfius}default-bootstrap>validation_belfius_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaybelfius}default-bootstrap>validation_belfius_4ec2334e63cb76d530be90814e3680c7'] = 'Belfius';
$_MODULE['<{multisafepaybelfius}default-bootstrap>validation_belfius_faf7180f053c55ff247b95a556e1b0de'] = 'U heeft gekozen af te rekenen met Belfius';
$_MODULE['<{multisafepaybelfius}default-bootstrap>validation_belfius_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaybelfius}default-bootstrap>validation_belfius_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaybelfius}default-bootstrap>validation_belfius_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaybelfius}default-bootstrap>validation_belfius_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaybelfius}default-bootstrap>payment_e2ab567838c0aa83f27cb712bb9f734e'] = 'Belfius';
$_MODULE['<{multisafepaybelfius}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaybelfius}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';