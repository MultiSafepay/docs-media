<?php
/**
 * MultiSafepay Payment Module
 *
 *  @author    MultiSafepay <integration@multisafepay.com.com>
 *  @copyright Copyright (c) 2020 MultiSafepay (https://www.multisafepay.com)
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

class Msp_Lock
{
    private $lockLocation;

    /**
     * Msp_Lock constructor.
     * @param string $lockLocation
     */
    public function __construct($lockLocation)
    {
        $this->lockLocation = $lockLocation;
    }

    /**
     * Check if an lock is active
     *
     * @param $tries
     * @return bool
     */
    public function isLockActive($tries)
    {
        $attempts = 0;
        while ($attempts < $tries) {
            if (!file_exists($this->lockLocation)) {
                return false;
            }
            sleep(1);
            $attempts++;
        }
        return true;
    }

    /**
     * Lock an given lock location
     */
    public function lock()
    {
        fopen($this->lockLocation, "w");
    }

    /**
     * Unlock a given lock
     */
    public function unlock()
    {
        if (file_exists($this->lockLocation)) {
            unlink($this->lockLocation);
        }
    }
}
