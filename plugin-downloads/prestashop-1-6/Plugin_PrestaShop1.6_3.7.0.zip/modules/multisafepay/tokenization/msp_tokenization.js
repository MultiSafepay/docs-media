/*
 * Tokenization JS
 * Copyright @ Adviva
 */

window.MSP_TKN = {};

//jQuery(window).load(function() {
	//jQuery.uniform.restore("#msp_save_my_card_check");
//});

/*
 * MSP_TKN.Tokenization 
 * 
 */
(function(){
    var _cfg = {},
    	_form = false,
    	_submitBtn = false,
    	_saveCardCheckbox = false,
    	_token_list = false,

	_initDom = function() {
		/* Save my card checkbox */
		_saveCardCheckbox = jQuery('#msp_save_my_card_check').change(function(){
			jQuery('#msp_tpo_savecard_box').toggle();
		});		
		if(_saveCardCheckbox.prop('checked')){
			jQuery('#msp_tpo_savecard_box').show();
		}else{
			jQuery('#msp_tpo_savecard_box').hide();
		}
		_saveCardInput = jQuery('#msp_save_my_card_name');		
		/* Help button */
		var _helpBtn = jQuery("#msp_tpo_help_btn").fancybox({
			'href': '#msp_tpo_help_box'
		});
		/* Form and submit */
		_form = jQuery('#msp_tokenization').closest('form').submit(_onSubmit);
		_submitBtn = _form.find('input[type=submit]').click(_onSubmit);
		/* Tokens */
		_token_list = jQuery('#msp_token_list');
		jQuery('.msp_token_gp_delete').click(_onTokenDelete);
		if(_token_list.find('#token_gp_new_card').prop('checked')){
			jQuery('#msp_token_payment_options_new_card').show();
		}
		_token_list.find('input').change(_onTokenChange);		
		
		//faultback to images if fontawesome icons is not loaded
		if(_helpBtn.find('.fa').css('font-family') !== 'FontAwesome'){
			jQuery('#msp_tokenization').addClass('msp-no-font-awesome');
		}
		
	},
	
	_onSubmit = function(evt) {
		evt.preventDefault();
		evt.stopPropagation();
		_form.find('.has-error').removeClass('has-error');
		if(_saveCardCheckbox.prop('checked')){
			if(_saveCardInput.val() == ''){
				jQuery('#msp_tpo_savecard_box').show();
				_saveCardInput.closest('.form-group').addClass('has-error');
				return;
			}
		}
		_form.off('submit').submit(); /* remove listner to avoid too much recursion */		
	},
	
	_onTokenChange = function(evt) {
		var el = $(this);
		if(el.attr('id') == 'token_gp_new_card'){
			jQuery('#msp_token_payment_options_new_card').show();
		}else{
			jQuery('#msp_token_payment_options_new_card').hide();
		}
	},
	
	_onTokenDelete = function(evt) {
		evt.preventDefault();
		evt.stopPropagation();
		var el = $(this);
		el.find('i').toggleClass('fa-spinner fa-trash-o');
		jQuery('#msp_token_errors').html('');
		$.ajax({
			type: 'POST',
			dataType: 'json',
			url: _cfg.token_manager_url,
			data: "id_token="+el.val()+"&action=del",
			success: function(data){
				el.find('i').toggleClass('fa-spinner fa-trash-o');
				if(data.success){
					el.parent().remove();
					var token_list = _token_list.find('li');
					if(token_list.length > 0){
						token_list.first().find('input').prop('checked', true);
						if(typeof $.uniform == 'object'){
							$.uniform.update(token_list.first().find('input'));
						}
					}else{
						// add new credit card will be always present
					}
				}else{
					jQuery('#msp_token_errors').append('<div class="alert alert-danger">' + data.message + '</div>');
				}
			},
			error: function(){
				jQuery('#msp_token_errors').append('<div class="alert alert-danger">' + data.message + '</div>');
			}
		});
	};	

    MSP_TKN.Tokenization = {
        init: function(cfg){
            _cfg = cfg;
            _initDom();
        }
    };
    
})();