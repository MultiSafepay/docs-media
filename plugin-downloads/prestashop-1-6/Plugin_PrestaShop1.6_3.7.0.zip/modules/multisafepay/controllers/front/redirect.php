<?php
/**
 * MultiSafepay Payment Module
 *
 *  @author    MultiSafepay <techsupport@multisafepay.com.com>
 *  @copyright Copyright (c) 2013 MultiSafepay (http://www.multisafepay.com)
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

class MultisafepayRedirectModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {

        /* wait maximal 10 seconds to give PrestaShop the time to create the order */
        $i = 0;
        do {
            sleep (1);
            $order = new Order(Order::getOrderByCartId((int)Tools::getValue('id_cart') ));
        } while ( empty ($order->id) && ++$i < 10);


        $url = "index.php?controller=order-confirmation"
                       . '&key='       . $order->secure_key
                       . '&id_cart='   . $order->id_cart
                       . '&id_module=' . Tools::getValue('id_module')
                       . '&id_order='  . Tools::getValue('id_order');
        Tools::redirect($url);
    }
}

