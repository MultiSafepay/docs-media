# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

***

## 3.7.0
Release date: Nov 25th, 2021

### Added
+ DAVAMS-232: Add support for in3 payment method
+ PLGPRSS-420: Add Payment Component support for Credit Card payment method
+ PLGPRSS-409: Add support for gift products within the Shopping Cart object
+ PLGPRSS-406: Add support for Good4fun gift card

### Fixed
+ PLGPRSS-414: Fix locale code when submit the Order Request, which was generating errors in case payment address code of the customer is different from the language selected

### Changed
+ PLGPRSS-408: When a payment is cancelled, the shopping cart will not be emptied
+ DAVAMS-314: Rebrand Klarna with new logo
+ DAVAMS-298: Rebrand Direct Bank Transfer as Request to Pay

***

## 3.6.0
Release date: Jul 21st, 2020

### Added
+ DAVAMS-269: Add CBC payment method

### Changed
+ DAVAMS-213: Add track & trace to shipment request
+ PLGPRSS-404: Set order to status shipped for all payment methods

***

## 3.5.0
Release date: Apr 9th, 2020

### Added
+ PLGPRSS-344: Add AfterPay

### Fixed
+ PLGPRSS-396: Correct spelling of ING Home'Pay
+ PLGPRSS-397: Fix incorrect gateway code for ING Home'Pay

***

## 3.4.0
Release date: Apr 2nd, 2020

### Added
+ PLGPRSS-400: Add Apple Pay
+ PLGPRSS-399: Add Direct Bank Transfer

***

## 3.3.0
Release date: Feb 26th, 2020

### Fixed
+ PLGPRSS-309: Prevent multiple transactions being created for the same order
+ PLGPRSS-391: Prevent duplicated orders by adding file locking
+ PLGPRSS-267: Mobile presentation of payment methods is not fully responsive

### Changed
+ PLGPRSS-190: Send shopping cart data for all payment methods
+ PLGPRSS-352: Improve parsing of address into street and apartment
