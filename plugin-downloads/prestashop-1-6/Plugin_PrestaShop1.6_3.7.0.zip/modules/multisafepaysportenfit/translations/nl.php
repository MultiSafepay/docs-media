<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_1b2d07018111fc5f1cf5d46f58dafe02'] = 'MultiSafepay Sport en Fit Cadeau';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_5cfccb3916cc34c5633cb60835b392d6'] = 'Accepteer Sport en Fit Cadeau betalingen via MultiSafepay';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_c888438d14855d7d96a2724ee9c306bd'] = 'Instellingen bijgewerkt';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_8af703b2bf59cc9742883ae7f4cb0e5b'] = 'Instellingen account';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_d876ff8da67c3731ae25d8335a4168b4'] = 'API-Sleutel';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_6e147eeb6094904219d0987806735f5c'] = 'De API-Sleutel van de betreffende website in het MultiSafepay account. Indien leeg, dan wordt de API-Sleutel van de Standaard MultiSafepay configuratie gebruikt.';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_b02b464fbe0b40f0c481f17894f66747'] = 'Test account';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_138780f997031206bb8ee5390e36e08a'] = 'Gebruik LIVE-account als de API-Sleutel van een Live-account is. Gebruik TEST-account als de API-Sleutel van een Test-account is.';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>multisafepaysportenfit_638ce87fab4d636ed19f2517b40a48fd'] = 'Live account';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>validation_sportenfit_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>validation_sportenfit_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>validation_sportenfit_8f08e18b62bd7560cdccdbc8ffb38706'] = 'Sport en Fit Cadeau';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>validation_sportenfit_7c556fcb9e8b43043481aac76e869ee1'] = 'U heeft gekozen om af te rekenen middels Sport en Fit Cadeau';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>validation_sportenfit_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>validation_sportenfit_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>validation_sportenfit_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>validation_sportenfit_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaysportenfit}default-bootstrap>payment_8f08e18b62bd7560cdccdbc8ffb38706'] = 'Sport en Fit Cadeau';
