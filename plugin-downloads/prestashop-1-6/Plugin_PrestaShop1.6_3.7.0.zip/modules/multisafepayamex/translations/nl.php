<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepayamex}default-bootstrap>multisafepayamex_00d979565f02db735926ff2621ff78fe'] = 'MultiSafepay American Express';
$_MODULE['<{multisafepayamex}default-bootstrap>multisafepayamex_0d795c2c60bfac9df5c5fbc6f29df246'] = 'Accepteer American Express betalingen via MultiSafepay';
$_MODULE['<{multisafepayamex}default-bootstrap>multisafepayamex_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepayamex}default-bootstrap>multisafepayamex_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepayamex}default-bootstrap>multisafepayamex_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepayamex}default-bootstrap>multisafepayamex_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepayamex}default-bootstrap>multisafepayamex_cd24746d3daba12f7de833ed6ab9adc3'] = 'Minimaal orderbedrag voor American Express';
$_MODULE['<{multisafepayamex}default-bootstrap>multisafepayamex_bb4954d24b85d1de27b88005debf768b'] = 'Maximaal orderbedrag voor American Express';
$_MODULE['<{multisafepayamex}default-bootstrap>validation_amex_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepayamex}default-bootstrap>validation_amex_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepayamex}default-bootstrap>validation_amex_d28e06acbeee71a5b573a392ae393ea1'] = 'AMEX';
$_MODULE['<{multisafepayamex}default-bootstrap>validation_amex_f3630da43a4c0837cd707f03ea0af542'] = 'U heeft gekozen af te rekenen met American Express';
$_MODULE['<{multisafepayamex}default-bootstrap>validation_amex_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepayamex}default-bootstrap>validation_amex_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepayamex}default-bootstrap>validation_amex_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepayamex}default-bootstrap>validation_amex_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepayamex}default-bootstrap>payment_b993f20c6e3b73949a96e934a76bbfef'] = 'American Express';
$_MODULE['<{multisafepayamex}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepayamex}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';