<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_2b7147eafc88c5dac7e7df126b1c4943'] = 'MultiSafepay Beauty and Wellness giftcard';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_0aa8b538b4fa6cff63d19b62242765e7'] = 'Accepteer Beauty and Wellness giftcard betalingen via MultiSafepay';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_c888438d14855d7d96a2724ee9c306bd'] = 'Instellingen bijgewerkt';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_8af703b2bf59cc9742883ae7f4cb0e5b'] = 'Algemene instellingen';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_d876ff8da67c3731ae25d8335a4168b4'] = 'API-Sleutel';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_6e147eeb6094904219d0987806735f5c'] = 'De API-Sleutel van de betreffende website in het MultiSafepay account. Indien leeg, dan wordt de API-Sleutel van de Standaard MultiSafepay configuratie gebruikt.';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_b02b464fbe0b40f0c481f17894f66747'] = 'Test account';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_138780f997031206bb8ee5390e36e08a'] = 'Gebruik LIVE-account als de API-Sleutel van een Live-account is. Gebruik TEST-account als de API-Sleutel van een Test-account is.';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>multisafepaybeautyandwellness_638ce87fab4d636ed19f2517b40a48fd'] = 'Live account';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>validation_beautyandwellness_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>validation_beautyandwellness_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>validation_beautyandwellness_d966fab5d1cc1e58b58dfb891b7679e8'] = 'Beauty and Wellness giftcard';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>validation_beautyandwellness_52faf77ec86443c5eb51f1a6b8eb4be0'] = 'U heeft gekozen om af te rekenen middels Beauty and Wellness giftcard';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>validation_beautyandwellness_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>validation_beautyandwellness_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>validation_beautyandwellness_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>validation_beautyandwellness_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaybeautyandwellness}default-bootstrap>payment_d966fab5d1cc1e58b58dfb891b7679e8'] = 'Beauty and Wellness giftcard';