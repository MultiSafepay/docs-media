<?php

class MultiSafepay_Msp_Model_Gateway_Billink extends MultiSafepay_Msp_Model_Gateway_Abstract
{
    protected $_code = "msp_billink";
    public $_model = "billink";
    public $_gateway = "BILLINK";
}
