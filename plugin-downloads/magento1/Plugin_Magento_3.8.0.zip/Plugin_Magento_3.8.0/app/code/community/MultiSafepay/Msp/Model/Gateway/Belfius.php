<?php

class MultiSafepay_Msp_Model_Gateway_Belfius extends MultiSafepay_Msp_Model_Gateway_Abstract
{
    protected $_code = "msp_belfius";
    public $_model = "belfius";
    public $_gateway = "BELFIUS";
}
