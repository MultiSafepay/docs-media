<?php
/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
/** @var $this MultiSafepay_Msp_Model_Setup */

$installer = $this;
$installer->startSetup();

// Remove Santander Betaal per Maand
$installer->deleteConfigData('msp_gateways/msp_betaalplan');

$installer->endSetup();
