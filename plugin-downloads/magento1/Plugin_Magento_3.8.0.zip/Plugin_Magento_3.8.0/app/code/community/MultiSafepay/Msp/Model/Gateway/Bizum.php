<?php

class MultiSafepay_Msp_Model_Gateway_Bizum extends MultiSafepay_Msp_Model_Gateway_Abstract
{
    protected $_code = "msp_bizum";
    public $_model = "bizum";
    public $_gateway = "BIZUM";
}
