<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Genericgiftcard1 extends MultiSafepay_Msp_Model_Gateway_Genericbase
{
    protected $_code = 'msp_generic_giftcard1';
    protected $_isGiftcard = true;
    public $_model = 'genericgiftcard1';
}
