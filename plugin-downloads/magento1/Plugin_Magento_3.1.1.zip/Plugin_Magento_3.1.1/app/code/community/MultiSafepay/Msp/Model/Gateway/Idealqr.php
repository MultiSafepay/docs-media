<?php

class MultiSafepay_Msp_Model_Gateway_Idealqr extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = "msp_idealqr";
    public $_model = "idealqr";
    public $_gateway = "IDEALQR";

}
