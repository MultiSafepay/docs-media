<?php

class MultiSafepay_Msp_Model_Gateway_Amex extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = "msp_amex";
    public $_model = "amex";
    public $_gateway = "AMEX";

    public $_formBlockType = 'msp/tokenization';

    public function assignData($data)
    {
        parent::assignData($data);
        $session = Mage::getSingleton('checkout/session');
        $session->setData('payment_additional', $data);
        return $this;
    }
}
