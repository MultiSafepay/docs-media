<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_GenericGateway1 extends MultiSafepay_Msp_Model_Gateway_GenericBase
{
    protected $_code = 'msp_generic_gateway1';
    protected $_isRegularGateway = true;
    public $_model = 'genericGateway1';
}
