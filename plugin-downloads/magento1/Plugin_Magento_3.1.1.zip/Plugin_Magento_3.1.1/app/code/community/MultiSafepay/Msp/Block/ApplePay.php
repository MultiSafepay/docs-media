<?php

class MultiSafepay_Msp_Block_ApplePay extends Mage_Payment_Block_Form
{
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('msp/applepay.phtml');
    }
}
