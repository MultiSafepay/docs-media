<?php

class MultiSafepay_Msp_Model_Gateway_Eps extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = "msp_eps";
    public $_model = "eps";
    public $_gateway = "EPS";

}
