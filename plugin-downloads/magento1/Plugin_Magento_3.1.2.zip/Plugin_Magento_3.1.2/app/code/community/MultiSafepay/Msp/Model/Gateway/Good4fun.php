<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Good4fun extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = 'msp_good4fun';
    public $_model = 'good4fun';
    public $_gateway = 'GOOD4FUN';

}
