<?php

class MultiSafepay_Msp_Model_Gateway_Dotpay extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = "msp_dotpay";
    public $_model = "dotpay";
    public $_gateway = "DOTPAY";

}
