<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Directebanking extends MultiSafepay_Msp_Model_Gateway_Abstract
{
    protected $_code = "msp_directebanking";
    public $_model = "directebanking";
    public $_gateway = "DIRECTBANK";
}
