<?php

class MultiSafepay_Msp_Block_Klarna extends Mage_Payment_Block_Form
{

    public $_code;
    public $_model;
    public $_countryArr = null;
    public $_country;
    public $_quote;

    protected function _construct()
    {
        $this->_quote = Mage::getSingleton('checkout/session')->getQuote();

        parent::_construct();
    }
}
