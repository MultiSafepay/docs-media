// Fix to solve the conflict between Select2, JQuery and Prototype
if ('NodeList' in window) {
    if (!NodeList.prototype.each && NodeList.prototype.forEach) {
        NodeList.prototype.each = NodeList.prototype.forEach;
    }
}
