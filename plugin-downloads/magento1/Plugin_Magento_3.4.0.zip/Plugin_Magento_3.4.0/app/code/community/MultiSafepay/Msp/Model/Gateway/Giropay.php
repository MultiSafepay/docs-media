<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Giropay extends MultiSafepay_Msp_Model_Gateway_Abstract
{
    protected $_code = "msp_giropay";
    public $_model = "giropay";
    public $_gateway = "GIROPAY";
}
