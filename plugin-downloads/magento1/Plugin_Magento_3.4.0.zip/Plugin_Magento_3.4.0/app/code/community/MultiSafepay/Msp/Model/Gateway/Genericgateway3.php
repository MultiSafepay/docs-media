<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Genericgateway3 extends MultiSafepay_Msp_Model_Gateway_Genericbase
{
    protected $_code = 'msp_generic_gateway3';
    protected $_isRegularGateway = true;
    public $_model = 'genericgateway3';
}
