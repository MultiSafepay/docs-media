<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Multisafepay extends MultiSafepay_Msp_Model_Gateway_Abstract
{
    protected $_code = "msp_multisafepay";
    public $_model = "multisafepay";
    public $_gateway = "WALLET";
}
