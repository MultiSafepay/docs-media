<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Genericgiftcard3 extends MultiSafepay_Msp_Model_Gateway_Genericbase
{
    protected $_code = 'msp_generic_giftcard3';
    protected $_isGiftcard = true;
    public $_model = 'genericgiftcard3';
}
