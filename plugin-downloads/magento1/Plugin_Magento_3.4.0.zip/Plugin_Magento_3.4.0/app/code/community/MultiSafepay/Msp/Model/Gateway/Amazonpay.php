<?php

/**
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Amazonpay extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = 'msp_amazonpay';
    public $_model = 'amazonpay';
    public $_gateway = 'AMAZONBTN';
}
