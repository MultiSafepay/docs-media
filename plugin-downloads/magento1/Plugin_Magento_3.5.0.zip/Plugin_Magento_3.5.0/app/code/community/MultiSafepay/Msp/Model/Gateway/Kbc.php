<?php

class MultiSafepay_Msp_Model_Gateway_Kbc extends MultiSafepay_Msp_Model_Gateway_Abstract
{
    protected $_code = "msp_kbc";
    public $_model = "kbc";
    public $_gateway = "KBC";
}
