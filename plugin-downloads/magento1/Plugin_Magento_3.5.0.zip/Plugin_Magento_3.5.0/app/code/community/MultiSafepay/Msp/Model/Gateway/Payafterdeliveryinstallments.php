<?php

class MultiSafepay_Msp_Model_Gateway_Payafterdeliveryinstallments extends MultiSafepay_Msp_Model_Gateway_Abstract
{
    protected $_code = "msp_payafterdeliveryinstallments";
    public $_model = "payafterdeliveryinstallments";
    public $_gateway = "BNPL_INSTM";
}
