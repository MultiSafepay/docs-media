<?php

class MultiSafepay_Msp_Model_Gateway_Alipayplus extends MultiSafepay_Msp_Model_Gateway_Abstract
{
    protected $_code = "msp_alipayplus";
    public $_model = "alipayplus";
    public $_gateway = "ALIPAYPLUS";
}
