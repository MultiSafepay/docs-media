<p align="center">
  <img src="https://www.multisafepay.com/img/multisafepaylogo.svg" width="400px" position="center">
</p>

# MultiSafepay plugin for Magento 1

Easily integrate MultiSafepay payment solutions into your Magento 1 webshop with the free and completely new MultiSafepay Magento 1 plugin.

## About MultiSafepay ##
MultiSafepay is a collecting payment service provider which means we take care of the agreements, technical details and payment collection required for each payment method. You can start selling online today and manage all your transactions from one place.
## Supported Payment Methods ##
The supported Payment Methods & Giftcards for this plugin can be found over here: [Payment Methods & Giftcards](https://docs.multisafepay.com/plugins/magento1/faq/#available-payment-methods-in-magento-1)

## Requirements
- To use the plugin you need a MultiSafepay account. You can create a test account on https://testmerchant.multisafepay.com/signup
- Magento 1.x

## Installation
### A) Via SFTP
1. Unpack the content of the .ZIP file in the root of your webshop
2. Login in your backend and navigate to System->Configuration->Cache. Clear your invalid cache.

### B) Via Modman
1. Install [Modman](https://github.com/colinmollenhour/modman)
2. 
<pre>
cd [magento root folder]
modman init
modman clone https://github.com/MultiSafepay/magento1-internal.git
</pre>
3. Login in your backend and navigate to System->Configuration->Cache. Clear your invalid cache.

For additional information or instructions please see our [installation & configuration manual](https://docs.multisafepay.com/plugins/magento1/manual/)

## A gift for your contribution
We look forward to receiving your input. Have you seen an opportunity to change things for better? We would like to invite you to create a pull request on GitHub.
Are you missing something and would like us to fix it? Suggest an improvement by sending us an [email](mailto:integration@multisafepay.com) or by creating an issue.

What will you get in return? A brand new designed MultiSafepay t-shirt which will make you part of the team!

## Support
You can create issues on our repository. If you need any additional help or support, please contact <a href="mailto:integration@multisafepay.com">integration@multisafepay.com</a>
