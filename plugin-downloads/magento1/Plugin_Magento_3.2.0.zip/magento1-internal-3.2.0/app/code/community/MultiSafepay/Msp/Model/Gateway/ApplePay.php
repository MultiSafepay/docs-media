<?php

/**
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_ApplePay extends MultiSafepay_Msp_Model_Gateway_Abstract
{
    protected $_code = "msp_applepay";
    public $_model = "applePay";
    public $_gateway = "APPLEPAY";
    protected $_formBlockType = 'msp/applePay';

    public function assignData($data)
    {
        parent::assignData($data);
        $session = Mage::getSingleton('checkout/session');
        $session->setData('payment_additional', $data);
        return $this;
    }
}
