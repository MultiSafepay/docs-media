<?php

class MultiSafepay_Msp_Model_Gateway_Cbc extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = 'msp_cbc';
    public $_model = 'cbc';
    public $_gateway = 'CBC';

}
