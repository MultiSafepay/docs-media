<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_GenericGiftcard1 extends MultiSafepay_Msp_Model_Gateway_GenericBase
{
    protected $_code = 'msp_generic_giftcard1';
    protected $_isGiftcard = true;
    public $_model = 'genericGiftcard1';
}
