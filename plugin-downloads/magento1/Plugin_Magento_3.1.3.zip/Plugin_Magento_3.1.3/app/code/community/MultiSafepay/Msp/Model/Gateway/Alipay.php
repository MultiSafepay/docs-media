<?php

class MultiSafepay_Msp_Model_Gateway_Alipay extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = "msp_alipay";
    public $_model = "alipay";
    public $_gateway = "ALIPAY";

}
